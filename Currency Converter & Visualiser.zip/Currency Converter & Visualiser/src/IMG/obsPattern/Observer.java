/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IMG.obsPattern;


   public abstract class Observer {
       
        protected Euro euro;
        
        public abstract void update();
}

